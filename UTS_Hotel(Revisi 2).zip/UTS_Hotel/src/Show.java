import java.util.Scanner;
public class Show {
    public Show(){
        System.out.println("Jumlah Pengunjung Diharapkan: " + Economy.harga / Inspect.totalKeuntungan);
        System.out.println("Jumlah Pengunjung: " + Main.jumlahPengunjung);
        System.out.println("Total Keuntungan: " + Inspect.totalKeuntungan);
        Main.Menu();
    }
}
